# GRC Cybersecurity Portfolio

Practical Governance, Risk, and Compliance projects designed to demonstrate analyst-level deliverables across risk assessment, compliance, third-party risk, policy governance, incident response, and control mapping.

## Portfolio Projects
- **01_NIST_Cybersecurity_Risk_Assessment** - End-to-end cyber risk assessment for a healthcare SaaS company using NIST-aligned methodology, including executive summary, risk matrix, risk register, and treatment plan.
- **02_NIST_CSF_Gap_Analysis** - Maturity and control gap analysis aligned to the NIST Cybersecurity Framework, including findings, target-state roadmap, and implementation priorities.
- **03_Third_Party_Vendor_Risk_Assessment** - Vendor security due diligence project including methodology, questionnaire, scoring logic, and sample assessment for a cloud service provider.
- **04_Information_Security_Governance_Policies** - Foundational governance package with core information security policy, access control policy, password standard, and incident response policy.
- **05_Incident_Response_Tabletop_Exercise** - Ransomware tabletop exercise package with scenario narrative, response roles, containment decisions, communications, and after-action improvements.
- **06_ISO27001_Control_Mapping** - Control crosswalk linking ISO/IEC 27001 Annex A controls to practical implementation evidence and related NIST CSF references.
- **07_SOC2_Readiness_Assessment** - SOC 2 readiness assessment aligned to Trust Services Criteria with gap ratings, remediation actions, and an audit preparation tracker.

## Why this portfolio is valuable
This repository is designed to showcase practical GRC work products that are commonly expected from analysts and junior consultants, including executive reports, registers, questionnaires, policy documents, control crosswalks, and readiness trackers.

## Key skills demonstrated
- Cybersecurity risk assessment
- Governance documentation and policy writing
- Compliance and framework gap analysis
- Third-party risk management
- Incident response planning
- Control mapping across frameworks
- Audit and readiness preparation

## Suggested resume summary
Built a practical cybersecurity GRC portfolio consisting of NIST-aligned risk assessments, CSF gap analyses, third-party risk reviews, policy governance documents, incident response exercises, ISO 27001 control mapping, and SOC 2 readiness assessments.

## Suggested repository structure
Each project folder contains a short `README.md` plus project deliverables in `.docx`, `.pdf`, and/or `.xlsx` format.

## Notes
All organizations, names, and scenarios are fictional and are intended solely to demonstrate professional GRC deliverables and analytical capability.