# Resume / LinkedIn Bullets

- Conducted NIST-aligned cybersecurity risk assessments, including asset inventory, threat identification, risk scoring, and treatment planning.
- Performed NIST CSF maturity and gap analyses and developed prioritized remediation roadmaps for management review.
- Designed third-party vendor risk questionnaires with weighted scoring logic and conditional approval criteria.
- Drafted information security governance documents including policy, access control, authentication, and incident response content.
- Built ransomware tabletop exercise materials, action logs, and after-action improvement plans.
- Mapped ISO 27001 control themes to practical implementation evidence and related NIST CSF references.
- Prepared SOC 2 readiness assessments with gap ratings, remediation tracking, and control ownership considerations.